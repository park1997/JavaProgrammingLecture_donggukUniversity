package ch13;

public class Animal {
	private String feed;
	Animal(String f){
		feed=f;
	}
	public String getFeed() {
		return feed;
	}
	public void setFeed(String feed) {
		this.feed = feed;
	}
	
}
