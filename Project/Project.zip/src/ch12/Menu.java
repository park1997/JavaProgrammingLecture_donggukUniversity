package ch12;

public class Menu {
	public void menu() {
		System.out.println("[ menu ]");
		System.out.println("0 : exit");
		System.out.println("1 : input\t(King Info.)");
		System.out.println("2 : show\t(King List)");
		System.out.println("3 : search\t(King name)");
		System.out.println("4 : menu");
	}
}
