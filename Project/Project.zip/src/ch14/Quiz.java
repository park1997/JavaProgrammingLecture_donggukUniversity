package ch14;
import java.util.*;
public class Quiz {
	int speed;

	
	public int speed_limit() {
		Random rand = new Random();
		int rand_num=rand.nextInt(4);
		int[] arr = {60,70,80,90};
		return arr[rand_num];
	}
	
	public int count(String src,String s) {
		int i=0;
		int count=0;
		while(i<src.length()) {
			if (src.charAt(i)==s.charAt(0) && src.charAt(i+1)==s.charAt(1)) {
				count+=1;
			}
			i+=1;
		}
		return count;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Quiz quiz = new Quiz();
		System.out.println("���Ѽӵ� = "+ quiz.speed_limit()+"km");
		
		
		String source = "The old man and the sea";
		System.out.println(quiz.count(source,"he"));
		
	}
	
}
