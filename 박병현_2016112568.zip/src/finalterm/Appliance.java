package finalterm;

public class Appliance {
	private String name;
	private int power;
	
	public Appliance(String name, int volt) {
		// TODO Auto-generated constructor stub
		this.name=name;
		this.power=volt;

	}

	public String getName() {
		return name;
	}

	public int getPower() {
		return power;
	}

	

	



}
